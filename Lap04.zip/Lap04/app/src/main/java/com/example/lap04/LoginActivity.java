package com.example.lap04;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    private EditText etEmail, etPassword;
    private TextView btnLogin, btnToMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.m001_act_login);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPass);
        btnLogin = findViewById(R.id.tvLogin);
        btnToMenu = findViewById(R.id.tvToMenu);

        // Khi nhấn Login
        btnLogin.setOnClickListener(v -> showCustomToast());

        // Chuyển sang English Learning
        btnToMenu.setOnClickListener(v -> {
            Intent i = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(i);
        });
    }

    private void showCustomToast() {
        String email = etEmail.getText().toString().trim();
        String pass = etPassword.getText().toString().trim();

        View layout = LayoutInflater.from(this).inflate(R.layout.toast_custom, null);
        TextView tvMsg = layout.findViewById(R.id.tvMsg);
        tvMsg.setText("Bạn đã đăng nhập thành công với email: " + email + "\nMật khẩu: " + pass);

        Toast toast = new Toast(this);
        toast.setView(layout);
        toast.setDuration(Toast.LENGTH_LONG);
        toast.show();
    }
}
