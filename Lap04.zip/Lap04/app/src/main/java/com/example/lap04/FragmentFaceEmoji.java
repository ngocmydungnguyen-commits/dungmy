package com.example.lap04;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import java.util.Random;

public class FragmentFaceEmoji extends Fragment implements View.OnClickListener {
    private static final int[] ids = {
            R.id.iv_face1, R.id.iv_face2, R.id.iv_face3,
            R.id.iv_face4, R.id.iv_face5, R.id.iv_face6,
            R.id.iv_face7, R.id.iv_face8, R.id.iv_face9
    };

    private static final int[] emojiIcons = {
            R.drawable.ic_angry, R.drawable.ic_baffle, R.drawable.ic_beauty,
            R.drawable.ic_boss, R.drawable.ic_choler, R.drawable.ic_dribble,
            R.drawable.ic_look_down, R.drawable.ic_sure, R.drawable.ic_tire
    };

    private Context mContext;
    private final Random random = new Random();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.m001_frg_face_emoji, container, false);
        for (int id : ids) root.findViewById(id).setOnClickListener(this);
        return root;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Override
    public void onClick(View v) {
        ImageView ivFace = (ImageView) v;
        showToast(ivFace.getDrawable());
    }

    private void showToast(Drawable drawable) {
        Toast toast = new Toast(mContext);
        ImageView ivEmoij = new ImageView(mContext);
        ivEmoij.setImageDrawable(drawable);
        toast.setView(ivEmoij);
        toast.setDuration(Toast.LENGTH_SHORT);
        toast.show();
    }

    // Random emoji
    public void randomEmojis() {
        View root = getView();
        if (root == null) return;

        for (int id : ids) {
            ImageView iv = root.findViewById(id);
            int randomIndex = random.nextInt(emojiIcons.length);
            iv.setImageResource(emojiIcons[randomIndex]);
        }
    }
}
