package com.example.lap04;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class FaceEmojiActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_face_emoji);

        Button btnBack = findViewById(R.id.btnBackToMenu);
        Button btnRandom = findViewById(R.id.btnRandom);

        // Quay về English Learning
        btnBack.setOnClickListener(v -> {
            Intent intent = new Intent(FaceEmojiActivity.this, MainActivity.class);
            startActivity(intent);
        });

        // Random emoji trong fragment
        btnRandom.setOnClickListener(v -> {
            FragmentFaceEmoji fragment = (FragmentFaceEmoji)
                    getSupportFragmentManager().findFragmentById(R.id.frg_face_emoij);
            if (fragment != null) {
                fragment.randomEmojis();
            }
        });
    }
}
