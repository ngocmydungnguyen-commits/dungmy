package com.example.lap06;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class CurrencyAdapter extends ArrayAdapter<String> {

    Context context;
    String[] currencyNames;
    int[] flags;

    public CurrencyAdapter(Context context, String[] currencyNames, int[] flags) {
        super(context, R.layout.item_currency, currencyNames);
        this.context = context;
        this.currencyNames = currencyNames;
        this.flags = flags;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return createView(position, parent);
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return createView(position, parent);
    }

    private View createView(int position, ViewGroup parent) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_currency, parent, false);

        ImageView imgFlag = view.findViewById(R.id.imgFlag);
        TextView txtCurrency = view.findViewById(R.id.txtCurrency);

        imgFlag.setImageResource(flags[position]);
        txtCurrency.setText(currencyNames[position]);

        return view;
    }
}
