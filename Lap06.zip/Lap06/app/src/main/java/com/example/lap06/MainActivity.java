package com.example.lap06;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Spinner spnFrom, spnTo;
    EditText edtAmount;
    Button btnConvert, btnGoLength;
    TextView txtResult;

    String[] currencyNames = {
            "USD", "EUR", "GBP", "INR", "AUD", "CAD", "ZAR", "NZD", "JPY", "VND"
    };

    int[] flags = {
            R.drawable.flag_us,
            R.drawable.flag_eu,
            R.drawable.flag_uk,
            R.drawable.flag_india,
            R.drawable.flag_australia,
            R.drawable.flag_canada,
            R.drawable.flag_south_africa,
            R.drawable.flag_new_zealand,
            R.drawable.flag_japan,
            R.drawable.flag_vietnam
    };

    double[][] rate = {
            {1, 0.91, 0.78, 83.5, 1.48, 1.36, 18.2, 1.63, 151.7, 24000},
            {1.10, 1, 0.86, 92.3, 1.63, 1.51, 20.1, 1.84, 167.8, 26300},
            {1.28, 1.16, 1, 107.2, 1.89, 1.75, 23.2, 2.12, 194.6, 30500},
            {0.012, 0.011, 0.0093, 1, 0.017, 0.016, 0.22, 0.019, 1.82, 285},
            {0.67, 0.61, 0.53, 59.6, 1, 0.92, 12.3, 1.12, 103.9, 16200},
            {0.73, 0.66, 0.57, 63.5, 1.08, 1, 13.4, 1.21, 112.4, 17500},
            {0.057, 0.05, 0.043, 4.64, 0.081, 0.075, 1, 0.09, 8.37, 1300},
            {0.61, 0.54, 0.47, 52.3, 0.89, 0.83, 11.2, 1, 102.4, 15900},
            {0.0066, 0.0059, 0.0051, 0.55, 0.0096, 0.0089, 0.12, 0.0098, 1, 156},
            {0.000042, 0.000038, 0.000033, 0.0035, 0.000062, 0.000057, 0.00077, 0.000063, 0.0064, 1}
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spnFrom = findViewById(R.id.spnFrom);
        spnTo = findViewById(R.id.spnTo);
        edtAmount = findViewById(R.id.edtAmount);
        btnConvert = findViewById(R.id.btnConvert);
        btnGoLength = findViewById(R.id.btnGoLength);
        txtResult = findViewById(R.id.txtResult);

        // GẮN CUSTOM ADAPTER
        CurrencyAdapter adapter = new CurrencyAdapter(this, currencyNames, flags);
        spnFrom.setAdapter(adapter);
        spnTo.setAdapter(adapter);

        btnConvert.setOnClickListener(v -> {
            String value = edtAmount.getText().toString();
            if (value.isEmpty()) {
                txtResult.setText("Vui lòng nhập số tiền!");
                return;
            }

            double amount = Double.parseDouble(value);
            int from = spnFrom.getSelectedItemPosition();
            int to = spnTo.getSelectedItemPosition();

            double result = amount * rate[from][to];

            txtResult.setText(amount + " " + currencyNames[from] + " = " + result + " " + currencyNames[to]);
        });

        btnGoLength.setOnClickListener(v ->
                startActivity(new Intent(MainActivity.this, LengthActivity.class))
        );
    }
}
