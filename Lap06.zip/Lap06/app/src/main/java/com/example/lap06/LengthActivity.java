package com.example.lap06;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class LengthActivity extends AppCompatActivity {

    Spinner spnFromLength, spnToLength;
    EditText edtValue;
    Button btnConvertLength;
    TextView txtLengthResult;

    String[] lengthUnits = {"km", "hm", "dam", "m", "dm", "cm", "mm"};

    double[] toMeter = {
            1000,   // km
            100,    // hm
            10,     // dam
            1,      // m
            0.1,    // dm
            0.01,   // cm
            0.001   // mm
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_length);

        spnFromLength = findViewById(R.id.spnFromLength);
        spnToLength = findViewById(R.id.spnToLength);
        edtValue = findViewById(R.id.edtValue);
        btnConvertLength = findViewById(R.id.btnConvertLength);
        txtLengthResult = findViewById(R.id.txtLengthResult);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, lengthUnits
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spnFromLength.setAdapter(adapter);
        spnToLength.setAdapter(adapter);

        btnConvertLength.setOnClickListener(v -> {
            String value = edtValue.getText().toString();
            if (value.isEmpty()) {
                txtLengthResult.setText("Vui lòng nhập số");
                return;
            }

            double input = Double.parseDouble(value);
            int from = spnFromLength.getSelectedItemPosition();
            int to = spnToLength.getSelectedItemPosition();

            double meterValue = input * toMeter[from];
            double result = meterValue / toMeter[to];

            txtLengthResult.setText(
                    input + " " + lengthUnits[from] + " = " +
                            result + " " + lengthUnits[to]
            );
        });
    }
}
