package com.example.lap08;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.*;

import java.util.ArrayList;

public class Bai1Activity extends AppCompatActivity {

    ListView listFood;
    ImageButton btnAdd;   // NÚT FLOATING BUTTON
    ArrayList<Food> data;
    FoodAdapter adapter;

    int[] imageList = {
            R.drawable.hamburger,
            R.drawable.banhmi,
            R.drawable.pho,
            R.drawable.comtam,
            R.drawable.banh_chuoi,
            R.drawable.milk_tea
    };

    String[] imageNames = {
            "Hamburger",
            "Bánh mì",
            "Phở",
            "Cơm tấm",
            "Bánh chuối",
            "Trà sữa"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai1);

        // ẨN ACTION BAR
        try { getSupportActionBar().hide(); } catch (Exception ignored) {}

        listFood = findViewById(R.id.listFood);
        btnAdd = findViewById(R.id.btnAdd);

        // Danh sách món ăn mặc định
        data = new ArrayList<>();
        data.add(new Food(R.drawable.hamburger, "Hamburger", "Bánh mì kẹp thịt", "40.000đ"));
        data.add(new Food(R.drawable.banhmi, "Bánh mì", "Bánh mì thịt nguội", "12.000đ"));
        data.add(new Food(R.drawable.pho, "Phở bò", "Phở tái nạm", "45.000đ"));
        data.add(new Food(R.drawable.comtam, "Cơm tấm", "Sườn - Bì - Chả", "35.000đ"));

        // Adapter
        adapter = new FoodAdapter(this, data, new FoodAdapter.OnFoodAction() {
            @Override
            public void edit(int pos) {
                showDialogEdit(pos);
            }

            @Override
            public void delete(int pos) {
                data.remove(pos);
                adapter.notifyDataSetChanged();
            }
        });

        listFood.setAdapter(adapter);

        // NÚT + (THÊM MÓN)
        btnAdd.setOnClickListener(v -> showDialogAdd());
    }

    // THÊM MÓN
    private void showDialogAdd() {

        View v = getLayoutInflater().inflate(R.layout.dialog_food, null);

        EditText edtName = v.findViewById(R.id.edtName);
        EditText edtDesc = v.findViewById(R.id.edtDesc);
        EditText edtPrice = v.findViewById(R.id.edtPrice);
        Spinner spImage = v.findViewById(R.id.spImage);

        ArrayAdapter<String> spAdapter =
                new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, imageNames);
        spImage.setAdapter(spAdapter);

        new AlertDialog.Builder(this)
                .setTitle("Thêm món ăn")
                .setView(v)
                .setPositiveButton("Thêm", (d, w) -> {

                    int index = spImage.getSelectedItemPosition();

                    data.add(new Food(
                            imageList[index],
                            edtName.getText().toString(),
                            edtDesc.getText().toString(),
                            edtPrice.getText().toString()
                    ));

                    adapter.notifyDataSetChanged();
                })
                .setNegativeButton("Hủy", null)
                .show();
    }

    // SỬA MÓN
    private void showDialogEdit(int pos) {

        Food f = data.get(pos);

        View v = getLayoutInflater().inflate(R.layout.dialog_food, null);

        EditText edtName = v.findViewById(R.id.edtName);
        EditText edtDesc = v.findViewById(R.id.edtDesc);
        EditText edtPrice = v.findViewById(R.id.edtPrice);
        Spinner spImage = v.findViewById(R.id.spImage);

        edtName.setText(f.getName());
        edtDesc.setText(f.getDesc());
        edtPrice.setText(f.getPrice());

        ArrayAdapter<String> spAdapter =
                new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, imageNames);
        spImage.setAdapter(spAdapter);

        int index = 0;
        for (int i = 0; i < imageList.length; i++) {
            if (imageList[i] == f.getImageRes()) {
                index = i;
                break;
            }
        }
        spImage.setSelection(index);

        new AlertDialog.Builder(this)
                .setTitle("Sửa món")
                .setView(v)
                .setPositiveButton("Lưu", (d, w) -> {

                    int imgIndex = spImage.getSelectedItemPosition();

                    f.setImageRes(imageList[imgIndex]);
                    f.setName(edtName.getText().toString());
                    f.setDesc(edtDesc.getText().toString());
                    f.setPrice(edtPrice.getText().toString());

                    adapter.notifyDataSetChanged();
                })
                .setNegativeButton("Hủy", null)
                .show();
    }
}
