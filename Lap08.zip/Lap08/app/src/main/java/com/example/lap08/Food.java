package com.example.lap08;

public class Food {
    private int imageRes;
    private String name;
    private String desc;
    private String price;

    public Food(int imageRes, String name, String desc, String price) {
        this.imageRes = imageRes;
        this.name = name;
        this.desc = desc;
        this.price = price;
    }

    public int getImageRes() { return imageRes; }
    public void setImageRes(int imageRes) { this.imageRes = imageRes; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDesc() { return desc; }
    public void setDesc(String desc) { this.desc = desc; }

    public String getPrice() { return price; }
    public void setPrice(String price) { this.price = price; }
}
