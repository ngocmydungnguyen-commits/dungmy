package com.example.lap08;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.GridView;

import java.util.ArrayList;

public class Bai2Activity extends AppCompatActivity {

    GridView gridView;
    ArrayList<Food> data;
    FoodGridAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bai2);

        gridView = findViewById(R.id.gridView);

        data = new ArrayList<>();

        data.add(new Food(R.drawable.hamburger, "Hamburger", "Bánh mì kẹp thịt", "40.000đ"));
        data.add(new Food(R.drawable.banhmi, "Bánh mì", "Bánh mì thịt nguội", "12.000đ"));
        data.add(new Food(R.drawable.pho, "Phở bò", "Phở tái nạm", "45.000đ"));
        data.add(new Food(R.drawable.comtam, "Cơm tấm", "Sườn - Bì - Chả", "35.000đ"));
        data.add(new Food(R.drawable.banh_chuoi, "Bánh chuối chiên", "Giòn – thơm", "10.000đ"));
        data.add(new Food(R.drawable.milk_tea, "Trà sữa", "Trân châu đường đen", "25.000đ"));

        adapter = new FoodGridAdapter(this, data);
        gridView.setAdapter(adapter);
    }
}
