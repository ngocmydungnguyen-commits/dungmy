package com.example.lap07;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnBai1, btnBai2, btnBai3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnBai1 = findViewById(R.id.btnBai1);
        btnBai2 = findViewById(R.id.btnBai2);
        btnBai3 = findViewById(R.id.btnBai3);

        btnBai1.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, B1_CustomButtonActivity.class);
            startActivity(intent);
        });

        btnBai2.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, B2_CustomDialogToastActivity.class);
            startActivity(intent);
        });

        btnBai3.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, B3_SeekbarActivity.class);
            startActivity(intent);
        });
    }
}
