package com.example.lap07;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.TextView;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class B3_SeekbarActivity extends AppCompatActivity {

    SeekBar skR, skG, skB;
    TextView tvR, tvG, tvB;
    View viewRGB, viewCMY;

    int r = 0, g = 0, b = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b3);

        skR = findViewById(R.id.skR);
        skG = findViewById(R.id.skG);
        skB = findViewById(R.id.skB);

        tvR = findViewById(R.id.tvR);
        tvG = findViewById(R.id.tvG);
        tvB = findViewById(R.id.tvB);

        viewRGB = findViewById(R.id.viewRGB);
        viewCMY = findViewById(R.id.viewCMY);

        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int value, boolean fromUser) {

                r = skR.getProgress();
                g = skG.getProgress();
                b = skB.getProgress();

                // cập nhật text
                tvR.setText("R = " + r);
                tvG.setText("G = " + g);
                tvB.setText("B = " + b);

                // RGB block
                viewRGB.setBackgroundColor(Color.rgb(r, g, b));

                // CMY block
                int c = 255 - r;
                int m = 255 - g;
                int y = 255 - b;

                viewCMY.setBackgroundColor(Color.rgb(c, m, y));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {}
        };

        skR.setOnSeekBarChangeListener(listener);
        skG.setOnSeekBarChangeListener(listener);
        skB.setOnSeekBarChangeListener(listener);
    }
}
