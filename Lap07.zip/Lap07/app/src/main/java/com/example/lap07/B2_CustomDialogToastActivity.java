package com.example.lap07;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class B2_CustomDialogToastActivity extends AppCompatActivity {

    Button btnShowToast, btnShowDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b2);  // giao diện bài 2

        btnShowToast = findViewById(R.id.btnShowToast);
        btnShowDialog = findViewById(R.id.btnShowDialog);

        // CUSTOM TOAST
        btnShowToast.setOnClickListener(v -> {
            LayoutInflater inflater = getLayoutInflater();
            View layout = inflater.inflate(R.layout.custom_toast, null);

            Toast toast = new Toast(getApplicationContext());
            toast.setDuration(Toast.LENGTH_SHORT);
            toast.setView(layout);
            toast.show();
        });

        // CUSTOM DIALOG
        btnShowDialog.setOnClickListener(v -> {
            Dialog dialog = new Dialog(B2_CustomDialogToastActivity.this);
            dialog.setContentView(R.layout.custom_dialog);

            Button ok = dialog.findViewById(R.id.btnOK);
            Button cancel = dialog.findViewById(R.id.btnCancel);

            ok.setOnClickListener(v1 -> {
                Toast.makeText(this, "Bạn đã đồng ý", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            });

            cancel.setOnClickListener(v12 -> dialog.dismiss());

            dialog.show();
        });
    }
}
