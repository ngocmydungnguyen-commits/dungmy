package com.example.lab5;

import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class AnimationActivity extends AppCompatActivity implements View.OnClickListener {

    private ImageView ivAnimal;
    private final int[] animList = {
            R.anim.alpha,
            R.anim.scale,
            R.anim.translate,
            R.anim.rotate
    };
    private final Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_animation);

        ivAnimal = findViewById(R.id.iv_animal);

        findViewById(R.id.btn_alpha).setOnClickListener(this);
        findViewById(R.id.btn_scale).setOnClickListener(this);
        findViewById(R.id.btn_trans).setOnClickListener(this);
        findViewById(R.id.btn_rotate).setOnClickListener(this);
        findViewById(R.id.btn_random).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        Animation anim = null;

        if (id == R.id.btn_alpha) {
            anim = AnimationUtils.loadAnimation(this, R.anim.alpha);
        } else if (id == R.id.btn_scale) {
            anim = AnimationUtils.loadAnimation(this, R.anim.scale);
        } else if (id == R.id.btn_trans) {
            anim = AnimationUtils.loadAnimation(this, R.anim.translate);
        } else if (id == R.id.btn_rotate) {
            anim = AnimationUtils.loadAnimation(this, R.anim.rotate);
        } else if (id == R.id.btn_random) {
            int randomAnim = animList[random.nextInt(animList.length)];
            anim = AnimationUtils.loadAnimation(this, randomAnim);
        }

        if (anim != null) {
            ivAnimal.startAnimation(anim);
        }
    }
}
