package com.example.lab5;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btnAnimation).setOnClickListener(this);
        findViewById(R.id.btnQuickCall).setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        if (id == R.id.btnAnimation) {
            startActivity(new Intent(this, AnimationActivity.class));
        } else if (id == R.id.btnQuickCall) {
            startActivity(new Intent(this, QuickCallActivity.class));
        }
    }
}
