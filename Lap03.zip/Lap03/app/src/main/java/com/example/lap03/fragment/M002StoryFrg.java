package com.example.lap03.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.lap03.R;

public class M002StoryFrg extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.m002_frg_story, container, false);

        // Lấy 2 item truyện
        View lnStory1 = view.findViewById(R.id.lnStory1);
        View lnStory2 = view.findViewById(R.id.lnStory2);

        // Hiệu ứng click nhẹ
        Animation clickAnim = AnimationUtils.loadAnimation(getContext(), R.anim.item_click);

        // Gắn sự kiện click
        lnStory1.setOnClickListener(v -> {
            v.startAnimation(clickAnim);
            openStoryDetail();
        });

        lnStory2.setOnClickListener(v -> {
            v.startAnimation(clickAnim);
            openStoryDetail();
        });

        return view;
    }

    private void openStoryDetail() {
        requireActivity().getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fr_container, new M003DetailFrg())
                .addToBackStack(null)
                .commit();
    }
}
