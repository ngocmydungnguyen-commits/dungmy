package com.example.lap03.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.lap03.R;

public class M001TopicFrg extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.m001_frg_topic, container, false);

        LinearLayout lnGirl = view.findViewById(R.id.lnTopicGirl);
        LinearLayout lnBoy = view.findViewById(R.id.lnTopicBoy);

        // Khi bấm vào chủ đề con gái
        lnGirl.setOnClickListener(v -> openStoryFragment("girl"));

        // Khi bấm vào chủ đề con trai
        lnBoy.setOnClickListener(v -> openStoryFragment("boy"));

        return view;
    }

    private void openStoryFragment(String topic) {
        FragmentTransaction ft = getParentFragmentManager().beginTransaction();
        Fragment storyFrg = new M002StoryFrg();

        Bundle args = new Bundle();
        args.putString("topic", topic);
        storyFrg.setArguments(args);

        ft.replace(R.id.fr_container, storyFrg);
        ft.addToBackStack(null);
        ft.commit();
    }
}
