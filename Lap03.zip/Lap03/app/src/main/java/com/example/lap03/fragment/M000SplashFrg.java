package com.example.lap03.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.lap03.R;

public class M000SplashFrg extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.m000_frg_splash, container, false);

        // ✅ Dùng Handler gắn với Looper chính để đảm bảo an toàn
        new Handler(Looper.getMainLooper()).postDelayed(this::gotoNext, 2000);

        return view;
    }

    private void gotoNext() {
        if (getActivity() == null || !isAdded()) return; // 🔒 kiểm tra an toàn
        try {
            getActivity().getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fr_container, new M001TopicFrg())
                    .addToBackStack(null)
                    .commitAllowingStateLoss(); // ✅ tránh crash khi activity đang recreate
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
