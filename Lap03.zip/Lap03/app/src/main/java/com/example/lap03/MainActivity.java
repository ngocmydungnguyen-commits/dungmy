package com.example.lap03;

import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;
import com.example.lap03.fragment.M000SplashFrg;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private SwitchCompat swRotate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        swRotate = findViewById(R.id.swRotate);
        swRotate.bringToFront(); // luôn nổi trên fragment

        // Khi bấm SwitchCompat
        swRotate.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Gọi animation xoay
            Animation rotateAnim = AnimationUtils.loadAnimation(this, R.anim.rotate_anim);
            swRotate.startAnimation(rotateAnim);

            if (isChecked) {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
            } else {
                setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
            }
        });

        // Hiển thị màn hình Splash đầu tiên
        showFrg(new M000SplashFrg());
    }

    private void showFrg(Fragment frg) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fr_container, frg)
                .commit();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_lang, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.lang_vi) {
            setLocale("vi");
            return true;
        } else if (id == R.id.lang_en) {
            setLocale("en");
            return true;
        } else if (id == R.id.lang_fr) {
            setLocale("fr");
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setLocale(String langCode) {
        Locale locale = new Locale(langCode);
        Locale.setDefault(locale);
        Configuration config = new Configuration();
        config.setLocale(locale);
        getBaseContext().getResources()
                .updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
        recreate();
    }
}
