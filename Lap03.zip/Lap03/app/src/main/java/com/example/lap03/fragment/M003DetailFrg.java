package com.example.lap03.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.lap03.R;

public class M003DetailFrg extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.m003_frg_detail, container, false);

        TextView tvTitle = view.findViewById(R.id.tvStoryTitle);
        TextView tvContent = view.findViewById(R.id.tvStoryContent);
        ImageView imgStory = view.findViewById(R.id.imgStory);
        Button btnBack = view.findViewById(R.id.btnBack);

        // Nhận dữ liệu từ Bundle
        Bundle args = getArguments();
        if (args != null) {
            tvTitle.setText(args.getString("title"));
            tvContent.setText(args.getString("content"));
            int imgRes = args.getInt("imageRes", R.drawable.img_rabbit);
            imgStory.setImageResource(imgRes);
        }

        btnBack.setOnClickListener(v -> requireActivity()
                .getSupportFragmentManager()
                .popBackStack());

        return view;
    }
}

